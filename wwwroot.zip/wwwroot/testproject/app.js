var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
// var prettyjson = require('prettyjson');

// var bodyParser = require('body-parser');
var routes = require('./routes/index');
var users = require('./routes/users');
var about = require('./routes/about');
var db;

//**DB Connect
var mongo = require('mongodb').MongoClient;
var uri = "mongodb://admin:admin@ds032319.mlab.com:32319/tobyproject";
mongo.connect(uri, function (err, _db) {
  db = _db;
  if (err) {
    console.log("Error: unable to connect to db");
    return;
  }
  console.log("Connected correctly");
});
//**DB Connect

//*TEST
// console.log("Test");
// var mongoose = require('mongoose');
// var options = { server: { socketOptions: { keepAlive: 300000, connectTimeoutMS: 30000 } }, 
//                 replset: { socketOptions: { keepAlive: 300000, connectTimeoutMS : 30000 } } }; 
// var mongodbUri = 'mongodb://admin:admin@ds032319.mlab.com:32319/tobyproject';
// mongoose.connect(mongodbUri, options);
// var conn = mongoose.connection;
// conn.on('error', console.error.bind(console, 'connection error:'));  
// conn.once('open', function() {
//   console.log("Connected correctly");
//   });
//*TEST

var app = express();

var bodyParser = require('body-parser');

app.use(bodyParser.json()); // support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true })); // support encoded bodies

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(require('less-middleware')(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname, 'public')));

// Routes
// app.use('/', routes);
// app.use('/users', users);
// app.get('/about', about);

app.get('/', function (req, res, next) {
  res.render('index', { title: 'RESTful Restaurant' });

});

//*** Read(GET)
app.get('/restaurant', function (req, res, next) {
  // console.log(db.collection('restaurant').find());
  // console.log(db.collection('restaurant').find().toArray());
  // var jsonObj = { "restaurants": [] };

  var cursor = db.collection('restaurant').find();
  // var cursor = db.collection('restaurant').find({ "restaurant_id": "30011111" });// find by name
  cursor.toArray(function (err, docs) {
    console.log(docs);
    res.json(docs);
  });
  
  // cursor.each(function (err, doc) {
  //   console.log(cursor.count());
  //   console.log(doc);
  //   jsonObj.restaurants.push(doc);
  // });
  // res.end(JSON.stringify(jsonObj));
});

//*** Read(GET) by id
app.get('/restaurant/:restaurant_id', function (req, res, next) {
  // console.log(db.collection('restaurant').find());
  // console.log(db.collection('restaurant').find().toArray());
  // var jsonObj = { "restaurants": [] };
  var restaurant_id = req.params.restaurant_id;
  var cursor = db.collection('restaurant').findOne({"restaurant_id" : restaurant_id}, 
    function (err, doc) {
    console.log(doc);
    if(err||!doc) {
      res.status(404).json({ error: 'Not Found' });
    }
    else {
      res.json(doc);
    }
  });
  
  // cursor.each(function (err, doc) {
  //   console.log(cursor.count());
  //   console.log(doc);
  //   jsonObj.restaurants.push(doc);
  // });
  // res.end(JSON.stringify(jsonObj));
});

//*** Read(GET) by name
app.get('/restaurant/name/:name', function (req, res, next) {
  // console.log(db.collection('restaurant').find());
  // console.log(db.collection('restaurant').find().toArray());
  // var jsonObj = { "restaurants": [] };
  var name = req.params.name;
  var cursor = db.collection('restaurant').findOne({"name" : name}, function (err, doc) {
    console.log(doc);
    if(err||!doc) {
      res.status(404).json({ error: 'Not Found' });
    }
    else {
      res.json(doc);
    }
  });
  
  // cursor.each(function (err, doc) {
  //   console.log(cursor.count());
  //   console.log(doc);
  //   jsonObj.restaurants.push(doc);
  // });
  // res.end(JSON.stringify(jsonObj));
});

//*** Create(POST)
app.post('/restaurant/:restaurant_id', function (req, res) {
  var restaurant_id = req.params.restaurant_id;
  var name = req.body.name;
  var address = req.body.address;
  
  var cursor = db.collection('restaurant').findOne({"restaurant_id" : restaurant_id}, 
    function (err, doc) {
    console.log(doc);
    if(!doc) {
      db.collection('restaurant').insertOne({
        "restaurant_id": restaurant_id,
        "name": name,
        "address": address
        }, function(err, results) {
        console.log("Inserted a document into the restaurant collection.");
        res.json({"result":"ok"});
        }
      ); 
    }
    else {
      res.status(409).json({ error: 'Already Exists' });
    }
  });
});

//*** Update(PUT)
app.put('/restaurant/:restaurant_id',function (req, res) {
  var restaurant_id = req.params.restaurant_id;
  var name = req.body.name;
  var address = req.body.address;
  var cursor = db.collection('restaurant').findOne({"restaurant_id" : restaurant_id}, 
    function (err, doc) {
    console.log(doc);
    if(doc) {
      db.collection('restaurant').update(
        {"restaurant_id" : restaurant_id},
        {
          $set:{"name" : name, 
            "address" : address}
        }, {}, function(err, results) {
          console.log("Update restaurant document.");
          console.log(results);
          res.json({"result":"ok"});
        }
      );
    }
    else {
      res.status(404).json({ error: 'Not Found' });
    }
  });
});

//*** Delete(DELETE)
app.delete('/restaurant/:restaurant_id', function (req, res){
  var restaurant_id = req.params.restaurant_id;
  var cursor = db.collection('restaurant').findOne({"restaurant_id" : restaurant_id}, 
    function (err, doc) {
    console.log(doc);
    if(doc) {
      db.collection('restaurant').deleteOne({
        "restaurant_id" : restaurant_id
        }, function(err, results) {
          console.log("Delete restaurant document.");
          console.log(results);
          res.json({"result":"ok"});
        }
      );  
    }
    else {
      res.status(404).json({ error: 'Not Found' });
    }
  });
});

//**DB CATCH ERROR
app.get('/docs', function (req, res, next) {
  routes.find({}, function (err, docs) {
    if (err) return next(err);
  });
});
//**DB CATCH ERROR

// catch 404 and forward to error handler
app.use(function (req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handlers

// development error handler
// will print stacktrace
if (app.get('env') === 'development') {
  app.use(function (err, req, res, next) {
    res.status(err.status || 500);
    res.render('error', {
      message: err.message,
      error: err
    });
  });
}

// production error handler
// no stacktraces leaked to user
app.use(function (err, req, res, next) {
  res.status(err.status || 500);
  res.render('error', {
    message: err.message,
    error: {}
  });
});




module.exports = app;
